
function demo_CQMC_sphpoly

%--------------------------------------------------------------------------
% OBJECT.
%--------------------------------------------------------------------------
% In this demo we compute a cubature rule on spherical polygons via QMC
% formulae.
%
% Once the domain is available, we compute a full rule QMC and a compressed
% one, say CQMC, sharing the same integrals for polynomials up to a total
% degree.
%--------------------------------------------------------------------------
% DATES
%--------------------------------------------------------------------------
% First version: March, 2023;
% Updated: April 15, 2023.
%--------------------------------------------------------------------------
% AUTHORS
%--------------------------------------------------------------------------
% G. Elefante, A. Sommariva, M. Vianello
%--------------------------------------------------------------------------
% PAPER
%--------------------------------------------------------------------------
% "Qsurf: compressed QMC integration on algebraic surfaces"
% G. Elefante, A. Sommariva and M. Vianello
%--------------------------------------------------------------------------
% ATTACHED ROUTINES
%--------------------------------------------------------------------------
% 1. pts_domain
% 2. referenceIntegral
% 3. pts_in_sphpol
% 4. test_fun
%--------------------------------------------------------------------------
% EXTERNAL ROUTINES
%--------------------------------------------------------------------------
% 1. dCATCH (and its subroutines)
% 2. cqmc_v2 (and its subroutines)
%--------------------------------------------------------------------------
% REMARKS
%--------------------------------------------------------------------------
% a) The code may require more than 16GB of RAM. In case of needs, use an
% inferior cardinality (i.e. set a lower value in "card").
%
% b) The code is time consuming. Experiments may take several minutes.
% Example: on a Mac Book Pro, with 16 MB of RAM and M1 processor, we get 
% that the elapsed time is 325.92 seconds (example: Africa with 2500000 
% points).
%--------------------------------------------------------------------------
% COPYRIGHT
%--------------------------------------------------------------------------
% Copyright (C) 2023  Giacomo Elefante, Alvise Sommariva and Marco Vianello
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <https://www.gnu.org/licenses/>.
%--------------------------------------------------------------------------

% domain 1: 
% 1. 4 Vertices Polygon, 
% 2. 7 Vertices Polygon 
% 3. Continental Australia
% 4. Continental America 
% 5. Continental Africa
% -> Suggested value: 5.
example = 5;

% Compressed QMC degree of precision to be analysed.
% suggested: 3:3:15
degV = 3:3:15;

% Cardinality of the pointset on minimal spherical cap containing the
% spherical polygon.
%
% -> Suggested values:
% example 1: card = 4000000; 
% example 2: card = 12000000; 
% example 3: card = 2500000;
% example 4: card = 2500000;
% example 5: card = 2500000;
card =2500000;

% QMC compression.
% method: 0: dCATCH;     1: CQMC_v2 (suggested)
method = 1;

% Test functions:
% 1: exp(-((x-x0(1)).^2 + (y-x0(2)).^2 + (y-x0(3)).^2))
% 2: cos(x+y+z)
% 3: ((x-x0(1)).^2 + (y-x0(2)).^2 + (y-x0(3)).^2).^(5/2)
% 4: 1
test_function = 1;

% Low discrepancy set.
% pointset_type: string determining the low discrepancy sets to be used:
%             'S': sobolset, 'H': haltonset, 'R': random
% -> suggested: 'H'.
pointset_type='H';

% Plot.
% 0: no plot, 1: plot.
do_plot=1;

% ............... Some technical parameters for compression ...............

tol=1e-10; % Compression tolerance.
compression_type=2; % 1: lsqnonneg 2: LHDM. (suggested: 2)



% ............................ Main code below ............................

addpath(genpath('SPHERICAL_DOMAINS'));


% ....................... Define compression of QMC rule ..................

switch method
    case 0
        met = 'dCATCH';
    case 1
        met = 'CQMC_v2';
end

% ....................... Define points in the domain .....................

fprintf('\n \t * Defining pointset in the domain (time consuming).');
tStart1 = tic;
[XYZ,V,x0,Area]=pts_domain(example,pointset_type,card);
cpu_tme1 = toc(tStart1);

W = ones(size(XYZ,1),1)/size(XYZ,1)*Area;

% ........................... Define integrands ...........................

f =test_fun(test_function,x0);

TrueInt = referenceIntegral(f,V);


fprintf('\n \n \t ................... QMC RULE ...................... \n' )

Iqmc=W'*feval(f,XYZ(:,1),XYZ(:,2),XYZ(:,3));
AEqmc = abs(Iqmc-TrueInt);
REqmc = abs(AEqmc/TrueInt);
fprintf('\n \t Ref value         : %1.15e',TrueInt);
fprintf('\n \t QMC value         : %1.15e',Iqmc);
fprintf('\n \n \t ae  QMC-TrueInt   : %1.2e',AEqmc);
fprintf('\n \t re  QMC-TrueInt   : %1.2e',REqmc);
fprintf('\n \n \t cpu time QMC      : %1.2e \n',cpu_tme1);

fprintf('\n \t ................... COMPRESSION .................... \n')

fprintf('\n \n \t * method: %s',met);
Ic=[]; ae=[]; re=[]; aeT=[]; reT=[]; SQMCcomp = []; i = 1;
for deg=degV

    fprintf('\n \n \t *  .... Performing compression, deg: %2.0f ....',...
        deg);
    tStart2 = tic;
    switch method
        case 0
            [T,w,res,dbox] = dCATCH(deg,XYZ,W);
        case 1
            [T,w,res,moms,LHDM_stats] = cqmc_v2(deg,XYZ,tol,...
                compression_type,W,2);
    end
    cpu_time2 = toc(tStart2);

    Ic(end+1) = w'*feval(f,T(:,1),T(:,2),T(:,3)); % integral by comp.rule

    ae(end+1) = abs(Ic(end)-Iqmc); % abs. error w.r.t. QMC
    re(end+1) = ae(end)/abs(Iqmc); % rel. error w.r.t. QMC
    aeT(end+1) = abs(Ic(end)-TrueInt); % abs. error w.r.t. ref. integral
    reT(end+1) = aeT(end)/abs(TrueInt); % rel. error w.r.t. ref. integral

    % statistics
    fprintf('\n \n \t QMC value        : %1.15e',Iqmc);
    fprintf('\n \t CQMC value       : %1.15e \n',Ic(end));

    for j=1:length(res)
        fprintf('\n \t residue iter %2d  : %1.2e',j,res(j));
    end
    fprintf('\n \n \t ae  CQMC-TrueInt : %1.2e',aeT(end));
    fprintf('\n \t re  CQMC-TrueInt : %1.2e',reT(end));
    fprintf('\n \t ae  CQMC-QMC     : %1.2e',ae(end));
    fprintf('\n \t re  CQMC-QMC     : %1.2e',re(end));

    fprintf('\n \n \t cpu_time CQMC    : %1.2e \n ',cpu_time2);

    SQMCcomp(i) = size(T,1); i = i+1;

end

%............................  Make statistics ............................

fprintf('\n \n \t ...................... STATISTICS .....................')
fprintf('\n \n \t Cardinality QMC    : %7.0f',size(XYZ,1));
for i = 1:length(SQMCcomp)
    fprintf('\n  \n \t CQMC degree        :    %2d',degV(i)) ;
    fprintf('\n \t Cardinality CQMC   :  %4.0f',SQMCcomp(i));
    fprintf('\n \t Compression ratio  :   %6.1f   ',size(XYZ,1)/SQMCcomp(i));
end

fprintf('\n \n \t .......................................................')

fprintf('\n \n');

%...............................  Make plots ..............................


if do_plot
    h=figure(1);
    f1=ishandle(h)&&strcmp(get(h,'type'),'figure');
    if f1,clf(1);end
    figure(1);
    [XX,YY,ZZ] = sphere;
    surf(XX,YY,ZZ,'EdgeColor',[181 181 181]/256,'FaceLighting',...
        'gouraud','FaceColor',[220 220 220]/256,'FaceAlpha',0.3)
    hold on;
    plot3(XYZ(:,1),XYZ(:,2),XYZ(:,3),'.','MarkerSize',4,'color',...
        'blue');

    plot3(T(:,1),T(:,2),T(:,3),'.','MarkerSize',4,'color',...
        [102 153 204]/256);
    str1=['Compressed set at degree ',num2str(degV(end))];
    legend('Sphere grid', 'QMC set',str1)
    hold off
end

















%--------------------------------------------------------------------------
% Additional routines
%--------------------------------------------------------------------------

function Iref =referenceIntegral(f,vertices)


%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% Computing reference integral "Iref" of function "f" over a spherical 
% domain with vertices "vertices".
%--------------------------------------------------------------------------

tol=1e-10;

Iref = adaptive_cub_sphpgon(vertices,f,tol);









function [X,V,CC,Area] = pts_domain(example,pts_type,N)

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% Depending on the variable "example", the routine:
%
% a) determines the vertices of the N sides spherical polygon whose
% vertices are stored in the N x 3 matrix V.
%
% b) computes the area of the spherical domain.
%
% c) determines a set of uniform points on the spherical domain, starting
% from "N" points in the "minimal cap" containing the domain.
%--------------------------------------------------------------------------


% ........................ domain definition ..............................

switch example
    case 1
        V = [0.4789    0.3966   -0.7832
            0.2813   -0.5443   -0.7904
            0.1032   -0.9815    0.1615
            0.3007    0.7574    0.5796];
    case 2
        V =[-0.4886   -0.5505    0.6769
            -0.3390   -0.4644    0.8182
            -0.3114   -0.6887   -0.6547
            -0.5290   -0.3708   -0.7633
            0.5768    0.7093   -0.4053
            -0.9359   -0.2140   -0.2799
            -0.6399   -0.7358    0.2216];
    case 3
        australia_pshape = coastline_australia(0);
        
        Vdeg = australia_pshape.Vertices;
        [Vx,Vy,Vz] = sph2cart(deg2rad(Vdeg(:,1)),deg2rad(Vdeg(:,2)),1);
        V = [Vx,Vy,Vz];
    case 4
        america_pshape = coastline_america;
        
        Vdeg = america_pshape.Vertices;
        [Vx,Vy,Vz] = sph2cart(deg2rad(Vdeg(:,1)),deg2rad(Vdeg(:,2)),1);
        V = [Vx,Vy,Vz];
    case 5
        africa_pshape = coastline_africa;
        
        polyAfrica = regions(africa_pshape);
        poly1 = polyAfrica(2);
        Vdeg = poly1.Vertices;
        [Vx,Vy,Vz] = sph2cart(deg2rad(Vdeg(:,1)),deg2rad(Vdeg(:,2)),1);
        V = [Vx,Vy,Vz];
end

% ................... area of the spherical polygon .......................

g = @(x,y,z) 1.*(x==x);

Area = adaptive_cub_sphpgon(V,g,1e-10);


% ................... points in the spherical polygon .....................

[X,CC] = pts_in_sphpol(N,pts_type,V);









function [X,CC] = pts_in_sphpol(N,pts_type,vertices)
%--------------------------------------------------------------------------
% OBJECT.
%--------------------------------------------------------------------------
% This function gives as output a set of N points inside a spherical
% polygon defined through its vertices.
%
% The procedure works as follows.
%
% a) It rotates the spherical polygon "S" to the North Pole by a suitable
% rotation of its centroid. Let "S1" br such rotated sph. polygon.
%
% b) Next, it considers the "minimal" spherical cap "C" containing that
% mapped spherical polygon "S1" and determines a set of N uniform points
% in "C".
%
% c) Vertices and points of "C" are mapped via the stereographic map to the
% plane and are considered only those remaining inside the planar polygon.
%
% d) Finally the points are rotated back to the original sph. poly. "S".
%--------------------------------------------------------------------------
% INPUT
%--------------------------------------------------------------------------
% N        : Cardinality of the points inside the minimal spherical cap.
% pts_type : 'H' Halton points, 'S' Sobol points, 'R' random points.
% vertices : Cartesian coordinates of the vertices of the sph. polygon.
%--------------------------------------------------------------------------
% OUTPUT
%--------------------------------------------------------------------------
% X        : cartesian coordinates of the points inside the sph. polygon.
% CC       : centroid of the region.
%--------------------------------------------------------------------------
% DATES
%--------------------------------------------------------------------------
% First version: March, 2023;
% Checked: April 5, 2023.
%--------------------------------------------------------------------------
% AUTHORS
%--------------------------------------------------------------------------
% G. Elefante, A. Sommariva, M. Vianello
%--------------------------------------------------------------------------
% PAPER
%--------------------------------------------------------------------------
% "Qsurf: compressed QMC integration on algebraic surfaces"
% G. Elefante, A. Sommariva and M. Vianello
%--------------------------------------------------------------------------
% RELEASE DATE
%--------------------------------------------------------------------------
% First version: March 2023
% Last update: March, 2023
%--------------------------------------------------------------------------
% .................... compute barycenter vertices ........................

R=norm(vertices(1,:)); vertices=vertices/R;
CC=mean(vertices); CC=CC/norm(CC);

% ................ rotation matrix centroid to north pole .................

[az,el,r] = cart2sph(CC(1),CC(2),CC(3));
phi=az; theta=pi/2-el;
cp=cos(phi); sp=sin(phi); ct=cos(theta); st=sin(theta);
R1=[ct 0 -st; 0 1 0; st 0 ct]; R2=[cp sp 0; -sp cp 0; 0 0 1];
rotmat=R1*R2; inv_rotmat=rotmat';

% ........................ rotate vertices to north pole...................

vertices_NP=(rotmat*vertices')';

% ..................... uniform points in the sphere cap...................

z_min = min(vertices_NP(:,3));

switch pts_type
    case 'H'
        p = haltonset(2);
        Xsq = net(p,N);
    case 'S'
        p = sobolset(2);
        Xsq = net(p,N);
    case 'R'
        Xsq = rand(N,2);
end

Xsq = [z_min+(1-z_min)*Xsq(:,1),2*pi*Xsq(:,2)];

XcapNP = [sqrt(1-Xsq(:,1).^2).*cos(Xsq(:,2)), ...
    sqrt(1-Xsq(:,1).^2).*sin(Xsq(:,2)), Xsq(:,1)];

% ................... stereographic map from south pole ...................

% ....... vertices .......

XX_SP=vertices_NP(:,1); YY_SP=vertices_NP(:,2); ZZ_SP=vertices_NP(:,3);
rat=1./(1+ZZ_SP);

XX_SPm=rat.*XX_SP; YY_SPm=rat.*YY_SP; % vertices on the plane

% ....... points .......

rat2=1./(1+XcapNP(:,3));
X_SP=rat2.*XcapNP(:,1); % points on the plane
Y_SP=rat2.*XcapNP(:,2);


% ........... polyshape of projected polygon from South Pole ..............

PG = polyshape(XX_SPm,YY_SPm);

in = isinterior(PG,X_SP,Y_SP);

Xin = [X_SP(in),Y_SP(in)]; % points in the planar polygonal domain

% mapping points to the spherical polygon at the North Pole
XinS = [2*Xin(:,1)./(1+Xin(:,1).^2+Xin(:,2).^2),...
    2*Xin(:,2)./(1+Xin(:,1).^2+Xin(:,2).^2),...
    (1-Xin(:,1).^2-Xin(:,2).^2)./(1+Xin(:,1).^2+Xin(:,2).^2)];

% mapping points to the required spherical polygon
X = (inv_rotmat*XinS')';













function f =test_fun(t_fun,x0)

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% Test functions:
% t_fun=1: exp(-((x-x0(1)).^2 + (y-x0(2)).^2 + (y-x0(3)).^2))
% t_fun=2: cos(x+y+z)
% t_fun=3: ((x-x0(1)).^2 + (y-x0(2)).^2 + (y-x0(3)).^2).^(5/2)
% t_fun=4: 1
%--------------------------------------------------------------------------

if nargin < 1, t_fun=1; end
if nargin < 2, x0=[1/2,1/2,franke(1/2,1/2)]; end

switch t_fun
    case 1
        f = @(x,y,z) exp(-((x-x0(1)).^2 + (y-x0(2)).^2 + (y-x0(3)).^2));
    case 2
        f = @(x,y,z) cos(x+y+z);
    case 3
        f = @(x,y,z) ((x-x0(1)).^2 + (y-x0(2)).^2 + (y-x0(3)).^2).^(5/2);
    case 4
        f = @(x,y,z) 1.*(x==x);
end







