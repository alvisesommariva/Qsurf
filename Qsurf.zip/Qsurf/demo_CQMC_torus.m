function demo_CQMC_torus

%--------------------------------------------------------------------------
% OBJECT.
%--------------------------------------------------------------------------
% In this demo we compute a cubature rule on a toroidal region via QMC
% formulae.
%
% Once the domain is available, we compute a full rule QMC and a compressed
% one, say CQMC, sharing the same integrals for polynomials up to a total
% degree.
%--------------------------------------------------------------------------
% DATES
%--------------------------------------------------------------------------
% First version: March, 2023;
% Checked: April 15, 2023.
%--------------------------------------------------------------------------
% AUTHORS
%--------------------------------------------------------------------------
% G. Elefante, A. Sommariva, M. Vianello
%--------------------------------------------------------------------------
% PAPER
%--------------------------------------------------------------------------
% "Qsurf: compressed QMC integration on algebraic surfaces"
% G. Elefante, A. Sommariva and M. Vianello
%--------------------------------------------------------------------------
% ATTACHED ROUTINES
%--------------------------------------------------------------------------
% 1. pts_domain
% 2. referenceIntegral
% 3. test_fun
%--------------------------------------------------------------------------
% EXTERNAL ROUTINES
%--------------------------------------------------------------------------
% 1. dCATCH (and its subroutines)
% 2. cqmc_v2 (and its subroutines)
%--------------------------------------------------------------------------
% REMARKS
%--------------------------------------------------------------------------
% a) The code may require more than 16GB of RAM. In case of needs, use an
% inferior cardinality (i.e. set a lower value in "card").
%
% b) The code is time consuming. Experiments may take several minutes.
% Example: on a Mac Book Pro, with 16 MB of RAM and M1 processor, we get 
% that the elapsed time is more than 1200 seconds.
%--------------------------------------------------------------------------
% COPYRIGHT
%--------------------------------------------------------------------------
% Copyright (C) 2023- 
%
% Authors:
% Giacomo Elefante, Alvise Sommariva, Marco Vianello.
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <https://www.gnu.org/licenses/>.
%--------------------------------------------------------------------------

% domain 2: 1. Full Torus, 2. Partial Torus
% see example on "Qsurf: compressed QMC integration on algebraic surfaces".
example = 1;

% Compressed QMC degree of precision to be analysed.
% -> suggested: 3:3:15
degV = 3:3:15;

% Cardinality of the pointset on the total torus, partial torus.
% -> suggested:  25000000;
card =25000000;

% Plot domains/pointsets: 0: no plot 1: plot.
do_plot = 1;

% QMC compression.
% method: 0: dCATCH;     1: CQMC_v2 (suggested)
method = 1;

% Test functions:
% 1: exp(-((x-x0(1)).^2 + (y-x0(2)).^2 + (y-x0(3)).^2))
% 2: cos(x+y+z)
% 3: ((x-x0(1)).^2 + (y-x0(2)).^2 + (y-x0(3)).^2).^(5/2)
% 4: 1
test_function = 1;

% Low discrepancy set.
% pointset_type: string determining the low discrepancy sets to be used:
%             'S': sobolset, 'H': haltonset, 'R': random
% -> suggested: 'H'.
pointset_type='H';

% Torus radii.
% -> suggested: r=2; R=3.
r=2; R=3;

% ............... Some technical parameters for compression ...............

tol=1e-10; % Compression tolerance. (suggested: 1e-10)
compression_type=2; % 1: lsqnonneg 2: LHDM. (suggested: 2)



% .......................... Main code below ..............................



% ....................... Define compression of QMC rule ..................

switch method
    case 0
        met = 'dCATCH';
    case 1
        met = 'CQMC_v2';
end

% ....................... Define points in the domain .....................

fprintf('\n \t * Defining pointset in the domain.');
tStart1 = tic;
[XYZ,x0,Area]=pts_domain(example,pointset_type,card,r,R);
cpu_tme1 = toc(tStart1);

W = ones(size(XYZ,1),1)/size(XYZ,1)*Area;

% ........................... Define integrands ...........................

f =test_fun(test_function,x0);

TrueInt=referenceIntegral(example,test_function,x0,r,R);


fprintf('\n \n \t ................... QMC RULE ...................... \n' )

Iqmc=W'*feval(f,XYZ(:,1),XYZ(:,2),XYZ(:,3));
AEqmc = abs(Iqmc-TrueInt);
REqmc = abs(AEqmc/TrueInt);
fprintf('\n \t Ref value         : %1.15e',TrueInt);
fprintf('\n \t QMC value         : %1.15e',Iqmc);
fprintf('\n \n \t ae  QMC-TrueInt   : %1.2e',AEqmc);
fprintf('\n \t re  QMC-TrueInt   : %1.2e',REqmc);
fprintf('\n \n \t cpu time QMC      : %1.2e \n',cpu_tme1);

fprintf('\n \t ................... COMPRESSION .................... \n')

fprintf('\n \n \t * method: %s',met);
Ic=[]; ae=[]; re=[]; aeT=[]; reT=[]; SQMCcomp = []; i = 1;
for deg=degV

    fprintf('\n \n \t *  .... Performing compression, deg: %2.0f ....',...
        deg);
    tStart2 = tic;
    switch method
        case 0
            [T,w,res,dbox] = dCATCH(deg,XYZ,W);
        case 1
            [T,w,res,moms,LHDM_stats] = cqmc_v2(deg,XYZ,tol,...
                compression_type,W,2);
    end
    cpu_time2 = toc(tStart2);

    Ic(end+1) = w'*feval(f,T(:,1),T(:,2),T(:,3));
    ae(end+1) = abs(Ic(end)-Iqmc); % abs. error w.r.t. QMC
    re(end+1) = ae(end)/abs(Iqmc); % rel. error w.r.t. QMC
    aeT(end+1) = abs(Ic(end)-TrueInt); % abs. error w.r.t. ref. integral
    reT(end+1) = aeT(end)/abs(TrueInt); % rel. error w.r.t. ref. integral

    fprintf('\n \n \t QMC value        : %1.15e',Iqmc);
    fprintf('\n \t CQMC value       : %1.15e \n',Ic(end));

    for j=1:length(res)
        fprintf('\n \t residue iter %2d  : %1.2e',j,res(j));
    end
    fprintf('\n \n \t ae  CQMC-TrueInt : %1.2e',aeT(end));
    fprintf('\n \t re  CQMC-TrueInt : %1.2e',reT(end));
    fprintf('\n \t ae  CQMC-QMC     : %1.2e',ae(end));
    fprintf('\n \t re  CQMC-QMC     : %1.2e',re(end));

    fprintf('\n \n \t cpu_time CQMC    : %1.2e \n ',cpu_time2);

    SQMCcomp(i) = size(T,1); i = i+1;

end




%............................  Make statistics ............................

fprintf('\n \n \t ...................... STATISTICS .....................')
fprintf('\n \n \t Cardinality QMC    : %7.0f',size(XYZ,1));
for i = 1:length(SQMCcomp)
    fprintf('\n  \n \t CQMC degree        :    %2d',degV(i)) ;
    fprintf('\n \t Cardinality CQMC   :  %4.0f',SQMCcomp(i));
    fprintf('\n \t Compression ratio  :   %6.1f   ',size(XYZ,1)/SQMCcomp(i));
end

fprintf('\n \n \t .......................................................')

fprintf('\n \n');




%...............................  Make plots ..............................

if do_plot


    x = linspace(0,2*pi,30);
    [A1,A2] = meshgrid(x);
    Tgrid1 = (r.*cos(A1)+R).*cos(A2);
    Tgrid2 = (r.*cos(A1)+R).*sin(A2);
    Tgrid3 = r.*sin(A1);

    h=figure(1);
    f1=ishandle(h)&&strcmp(get(h,'type'),'figure');
    if f1,clf(1);end
    figure(1);

    hold on;

    % torus as grid
    surf(Tgrid1,Tgrid2,Tgrid3,'EdgeColor',[181 181 181]/256,...
        'FaceLighting','gouraud','FaceColor',[220 220 220]/256,...
        'FaceAlpha',0.3);

    % QMC pointset
    plot3(XYZ(:,1),XYZ(:,2),XYZ(:,3),'.','MarkerSize',4,'color',...
        'blue');

    % CQMC pointset
    plot3(T(:,1),T(:,2),T(:,3),'.','MarkerSize',16,'color',...
        [204 102 0]/256);


    str1=['Compressed set at degree ',num2str(degV(end))];
    legend('torus grid','QMC set',str1)
    hold off


end







%--------------------------------------------------------------------------
% Additional routines
%--------------------------------------------------------------------------


function [X,CC,Area] = pts_domain(example,pts_type,N,r,R)

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% Depending on the variable "example", the routine:
%
% a) determines by rejection sampling a pointset in the domain defined by
% example (subset of a toroidal surface).
%
% b) computes the centroid "CC" of the domain.
%
% c) computes the area of the domain.
%--------------------------------------------------------------------------


% ........................ domain definition ..............................


V = [];

Area = 4*pi^2*R*r;

switch pts_type
    case 'H'
        p = haltonset(3);
        U = net(p,N);
    case 'S'
        p = sobolset(3);
        U = net(p,N);
    case 'R'
        U = rand(N,3);
end
U = U*2*pi;

% Density function over constant
d = @(x) (R+r*cos(x))/(R+r);

% Rejection sampling
Yidx = (U(:,3)-d(U(:,1))<=0);
Y = [U(Yidx,1:2)];

CC = [0,-R,r];

% Mapped rejection-sampling points to Torus
X = [(r.*cos(Y(:,1))+R).*cos(Y(:,2)),...
    (r.*cos(Y(:,1))+R).*sin(Y(:,2)),...
    r.*sin(Y(:,1))];

% Example 2 takes in consideration a subset of the torus.
if example == 2
    id = (-X(:,1)/4 + X(:,2) + 4*X(:,3) >=0);
    X = X(id,:);
    id2 = (X(:,1).^2+(X(:,2)-4).^2+X(:,3).^2-6>=0);
    X = X(id2,:);
    Area = 99.831703284960270;
end









function Iref=referenceIntegral(example,t_fun,x0,r,R)

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% Computing reference integral "Iref" of function "f" over a toroidal
% domain.
% The torus is defined by the origin as center and radii r < R.
%
% Furthermore "x0" is a chosen point (default [0,-R,r]), to define the 
% test function via "t_fun" parameter.
%--------------------------------------------------------------------------

if nargin < 1, example=1; end
if nargin < 2, t_fun=1; end
if nargin < 4, r=2; end
if nargin < 5, R=3; end
if nargin < 3, x0=[0,-R,r]; end

switch example
    case 1
        f=test_fun(t_fun,x0);
        h = @(x,y) f(((r.*cos(x)+R).*cos(y)),...
            ((r.*cos(x)+R).*sin(y)),(r.*sin(x)));
        g = @(x,y) h(x,y).*(R+r.*cos(x))*r;

        tol=10^(-10);
        Iref = integral2(g,0,2*pi,0,2*pi,'AbsTol',tol,'RelTol',tol);

    case 2
        if (r == 2) & (R == 3)
            switch t_fun % Generate via QMC with 20123259 points
                case 1
                    Iref = 7.739968123636733e-06;
                case 2
                    Iref = 12.928980908456362;
                case 3
                    Iref = 786058.705216490547173;
            end
        else
            warning('Reference result not available. Time consuming.');
            cardR=5*10^7;
            [XYZ,x0,Area]=pts_domain(example,'H',cardR,r,R);
            W = ones(size(XYZ,1),1)/size(XYZ,1)*Area;
            f=test_fun(t_fun,x0);
            Iref=W'*feval(f,XYZ(:,1),XYZ(:,2),XYZ(:,3));
        end
end










function f =test_fun(t_fun,x0)

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% Test functions:
% t_fun=1: exp(-((x-x0(1)).^2 + (y-x0(2)).^2 + (y-x0(3)).^2))
% t_fun=2: cos(x+y+z)
% t_fun=3: ((x-x0(1)).^2 + (y-x0(2)).^2 + (y-x0(3)).^2).^(5/2)
% t_fun=4: 1
%--------------------------------------------------------------------------

if nargin < 2, x0=[0,-R,r]; end

switch t_fun
    case 1
        f = @(x,y,z) exp(-((x-x0(1)).^2 + (y-x0(2)).^2 + (y-x0(3)).^2));
    case 2
        f = @(x,y,z) cos(x+y+z);
    case 3
        f = @(x,y,z) ((x-x0(1)).^2 + (y-x0(2)).^2 + (y-x0(3)).^2).^(5/2);
    case 4
        f = @(x,y,z) 1.*(x==x);
end





