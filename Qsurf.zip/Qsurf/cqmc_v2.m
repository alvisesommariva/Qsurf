
function [T,w,res,mom,LHDM_stats]=cqmc_v2(deg,X,tol,comp_type,wX,dom)

%--------------------------------------------------------------------------
% Object
%--------------------------------------------------------------------------
% The routine computes a Compressed Quasi-Monte Carlo formula from a large
% low-discrepancy sequence on a low-dimensional compact set preserving the
% QMC polynomial moments up to a given degree, via Tchakaloff sets and NNLS
% moment-matching.
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% deg: polynomial degree
% X: d-column array of a low-discrepancy sequence
% tol: moment-matching relative residual tolerance
% comp_type: compression algorithm. 1: lsqnonneg (default) 2: LHDM. 
% wX: weights corresponding to X
% dom: 1: full Chebyshev basis, 
%      2: subset of the Chebyshev basis depending on the numerical 
%         dimension of the polynomial space (default).
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% T: compressed points (subset of X).
% w: positive weights (corresponding to T).
% res: moment-matching relative residual
% mom: moments of a certain shifted tensorial Chebyshev basis (total
%   degree equal to deg).
% LHDM_stats: vector of cardinality and iterations along the compression
%     stages.
%--------------------------------------------------------------------------
% Dates
%--------------------------------------------------------------------------
% First version: May 28, 2022
% Last update:: April 15, 2023
%--------------------------------------------------------------------------
% Authors
%--------------------------------------------------------------------------
% G. Elefante, A. Sommariva, M. Vianello
%--------------------------------------------------------------------------
% Paper
%--------------------------------------------------------------------------
% 1. "CQMC: an improved code for low-dimensional Compressed Quasi-MonteCarlo
% cubature"
% 2. "Compressed QMC volume and surface integration on union of balls"
% G. Elefante, A. Sommariva and M. Vianello
%--------------------------------------------------------------------------
% COPYRIGHT
%--------------------------------------------------------------------------
% Copyright (C) 2023-
%
% Authors:
% Giacomo Elefante, Alvise Sommariva, Marco Vianello.
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <https://www.gnu.org/licenses/>.
%--------------------------------------------------------------------------


% ............................ Troubleshooting  ...........................

if nargin < 3, tol=10^(-10); end
if isempty(tol), tol=10^(-10); end

if nargin < 4, comp_type=1; end
if isempty(comp_type), comp_type=1; end

if nargin < 5, wX=ones(size(X,1),1); end
if isempty(wX), wX=ones(size(X,1),1); end

if nargin < 6, dom=2; end
if isempty(dom), dom=2; end


% ............................ Function body  .............................

M=length(X(:,1));

if M <= 0 
    fprintf(2,'\n \t No point in domain ');
    T=[]; w=[]; res=[]; q=[]; LHDM_stats=[]; return; 
end

% 1.2: Chebyshev-Vandermonde matrix of degree deg at X
[V,dbox,N] = dCHEBVAND_v2(deg,X,[],dom);

% 1.3: QMC moments
mom=V'*wX;

% 2: computing the compressed QMC formula
% 2.1: initializing the candidate Tchakaloff set cardinality
m=2*N; 
% 2.2: initializing the residual
res=2*tol;
% 2.3: increase percentage of a candidate Tchakaloff set
theta=2;
% iterative search of a Tchakaloff set by NNLS moment-matching
s=1;

LHDM_stats=[];
momtype = 0;

while res(end)>tol && m<=M
    % 2.4: reduced Chebyshev-Vandermonde matrix;
    Vm=V(1:m,:);
    
    % 2.5: qr-decomposition
    [Am,Rm]=qr(Vm,0);

    % 2.6: modified qmc moments
    switch momtype
        case 0
            qm=(mom'/Rm)';
        case 1
            AM = V/Rm;
            qm=AM'*wX;
            Am = Vm/Rm;
    end

    % 2.7: nonnegative weights by NNLS
    switch comp_type
        case 1
            % fprintf('\n \t -> lsqnonneg');
            [u,resnorm] = lsqnonneg(Am',qm);
            iter=NaN;
        case 2
            % fprintf('\n \t -> LHDM');
            [u,resnorm,~,iter] = LHDM(Am',qm);
    end
    
    % 2.8: relative residual
    res(s)=norm(Vm'*u-mom)/norm(mom);
    
    LHDM_stats=[LHDM_stats; m iter];
    
    % 2.9: updating the candidate Tchakaloff set cardinality
    if s>1 
        if (res(s-1)/res(s)<=10) && (momtype==0)
            momtype = 1;
            % 2.10 Recomputing the the weights with the different modified
            % moments without updates
            AM = V/Rm;
            qm=AM'*wX;
            Am = Vm/Rm;
            switch comp_type
                case 1
                    [u,resnorm] = lsqnonneg(Am',qm);
                    iter=NaN;
                case 2
                    [u,resnorm,~,iter] = LHDM(Am',qm);
            end
            s = s +1;
            res(s)=norm(Vm'*u-mom)/norm(mom);
        elseif (res(s-1)/res(s)<=10) && (momtype==1)
            m = M;
            s = s+1;
            continue;
        end
    end
    m=floor(theta*m);
    s=s+1;
end % while

% compressed formula
% 2.11: indexes of the positive weights
ind=find(u>0);

% 2.12: compressed support points selection
T=X(ind,:);

% 2.13: corresponding positive weights
w=u(ind);

