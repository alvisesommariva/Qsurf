
function [V,dbox,N] = dCHEBVAND_v2(deg,X,dbox,dom)

%--------------------------------------------------------------------------
% Object
%--------------------------------------------------------------------------
% This routine computes the Chebyshev-Vandermonde matrix for degree "deg"
% on a d-dimensional point cloud "X".
%
% The Chebyshev basis is the tensorial Chebyshev basis of total degree
% "deg", shifted on the hyperrectangle defined by "dbox".
%
% If "dbox" is not provided, the routine sets that variable to define the
% smaller "hyperrectangle" (box) with sides parallel to the cartesian
% axes and containing the pointset "X".
%--------------------------------------------------------------------------
% Input
%--------------------------------------------------------------------------
% deg: polynomial degree;
% X: d-column array of "m" points cloud (matrix "m x d");
% * dbox: variable that defines the smallest hyperectangle with sides
%     parallel to the axis, containing the domain.
%     If "dbox" is not provided, it defines the smaller "hyperrectangle", 
%     with sides parallel to the cartesian axes, containing the pointset 
%     "X". 
%     It is a matrix with dimension "2 x d", where "d" is the dimension  
%     of the space in which it is embedded the domain. 
%     For instance, for a 2-sphere, it is "d=3", while for a 2 dimensional
%     polygon it is "d=2".
%     As example, the set "[-1,1] x [0,1]" is described as "[-1 0; 1 1]".
% * dom: 1: Chebyshev-Vandermonde matrix (default), 
%        2: Chebyshev-Vandermonde matrix with the right numerical rank 
%         (useful for algebraic surfaces)
%
% Note: the variables with an asterisk "*" are not mandatory and can be 
% also set as empty matrix.
%--------------------------------------------------------------------------
% Output
%--------------------------------------------------------------------------
% V: shifted Chebyshev-Vandermonde matrix for degree "deg" on the pointset
%    "X", relatively to "dbox".
% dbox: variable that defines the hyperrectangle with sides parallel to the
%     axis, containing the domain.
% N: dimension of the polynomial space.
%--------------------------------------------------------------------------
% Previous versions.
%--------------------------------------------------------------------------
% This routine is an extension of dCHEBVAND, taking into account that for 
% domains "Omega" embedded in R^d the dimension of the polynomial space of 
% total degree "deg" may be inferior of that in the whole "R^d".
%--------------------------------------------------------------------------
% External routines
%--------------------------------------------------------------------------
% This routine requires:
% 1. mono_next_grlex (author: John Burkardt).
%--------------------------------------------------------------------------
% Dates
%--------------------------------------------------------------------------
% Written by M. Dessole, F. Marcuzzi, M. Vianello, on July 2020;
% Modified by G. Elefante, A. Sommariva, M. Vianello, on April 16, 2023.
%--------------------------------------------------------------------------
% COPYRIGHT
%--------------------------------------------------------------------------
% Copyright (C) 2020-
%
% Authors:
% Monica Dessole, Giacomo Elefante, Fabio Marcuzzi, Alvise Sommariva, 
% Marco Vianello
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <https://www.gnu.org/licenses/>.
%--------------------------------------------------------------------------


% ........................... Function body ...............................

% ...... troubleshooting ......

if nargin < 3, dbox=[]; end
if isempty(dbox) 
    a=min(X); b=max(X); dbox=[a; b];
else
    a=dbox(1,:); b=dbox(2,:);
end

if nargin < 4, dom=1; end
if isempty(dom), dom=1; end



% ..... main code below .....

% d-uples of indices with sum less or equal to "deg" graded lexicographical 
% order
d=size(X,2); N = nchoosek(deg+d,d); duples = zeros(N,d);
for i=2:N
    duples(i,:) = mono_next_grlex(d,duples(i-1,:)); 
end

% mapping the mesh in the hypercube "[-1,1]^d"
map = zeros(size(X));
for i=1:d
    map(:,i)=(2*X(:,i)-b(i)-a(i))/(b(i)-a(i)); 
end

% Chebyshev-Vandermonde matrix on the mesh
T=chebpolys(deg,map(:,1));
V0=T(:,duples(:,1)+1);
for i=2:d
    T=chebpolys(deg,map(:,i)); 
    V0=V0.*T(:,duples(:,i)+1); 
end

% Dimension of the polynomial space on X and Vandermonde matrix of the 
% right (numerical) dimension (w.r.t. the choosen polynomial space).
switch dom
    case 1
        N=length(V0(1,:)); V=V0;
    case 2
        nu=length(V0(1,:));
        N=rank(V0(1:nu,1:nu));
        [~,~,p] = qr(V0(1:nu,1:nu),0);
        Cp = V0(:,p);
        V = Cp(:,1:N);
end










function T=chebpolys(deg,x)

%--------------------------------------------------------------------------
% Object:
% This routine computes the Chebyshev-Vandermonde matrix on the real line
% by recurrence.
%--------------------------------------------------------------------------
% Input:
% deg: maximum polynomial degree
% x: 1-column array of abscissas
%--------------------------------------------------------------------------
% Output:
% T: Chebyshev-Vandermonde matrix at x, T(i,j+1)=T_j(x_i), j=0,...,deg.
%--------------------------------------------------------------------------
% Authors:
% Alvise Sommariva and Marco Vianello
% University of Padova, December 15, 2017
%--------------------------------------------------------------------------

T=zeros(length(x),deg+1);
t0=ones(length(x),1); T(:,1)=t0;
t1=x; T(:,2)=t1;

for j=2:deg
    t2=2*x.*t1-t0; 
    T(:,j+1)=t2;
    t0=t1; 
    t1=t2;
end




